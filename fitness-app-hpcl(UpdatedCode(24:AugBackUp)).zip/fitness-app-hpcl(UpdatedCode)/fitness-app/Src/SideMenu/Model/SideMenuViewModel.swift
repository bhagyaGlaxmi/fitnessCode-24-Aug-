//
//  SideMenuViewModel.swift
//  SideMenu
//
//  Created by Babu Lal Choudhary on 27/03/22.
//

import Foundation

enum SideMenuViewModel : Int, CaseIterable {
    
    //**Here in this screen leaderboard and last seven steps content is sir told to commented on 13/jul/2023 **//
    
    //case home
    case setGoal
    case setPreferences
    case pme
   // case leaderboard
   // case leaderboard1
  //  case lastsevendaysstepcount
    
    //case logout
    
    
    var title : String{
        switch self {
            
        case .setGoal : return "setGoal"
        case .setPreferences : return "setPreferences"
        case .pme : return "pme"
            //case .logout : return "logout"
      //  case .leaderboard : return "leaderboard"
     //   case .lastsevendaysstepcount : return "lastsevendaysstepcount"
        }
    }
    
    var imageName : String{
        switch self {
            
        case .setGoal : return "target"
        case .setPreferences : return "list.bullet.clipboard"
        case .pme : return "list.dash.header.rectangle"
    //    case .leaderboard : return "heart"
            //case .logout : return "arrow.left.square"
       
       
     //  case .lastsevendaysstepcount : return "figure.step.training"
            
        }
    }
        
        var isVisible : Bool{
            switch self {
                
            case .setGoal : return true
            case .setPreferences : return UserDefaults.standard.isPreferences
        case .pme : return UserDefaults.standard.pme
                //case .logout : return true
    //        case .leaderboard : return UserDefaults.standard.leaderboard
            
   //         case .lastsevendaysstepcount : return UserDefaults.standard.lastsevendaysstepcount
                                
            }
        }
        
    }


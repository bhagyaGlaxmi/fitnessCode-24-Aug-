//
//  AuthenticationViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation
import HomeKit
import SwiftUI
import HealthKit

class AuthenticationViewModel: ObservableObject {
    
    
    @Published var isSuccess = false;
    
    @Published var isLoginSuccess = false;
    @Published  var errorMessage = "";
    @Published var isLoading = false;
    @Published  var isShowingAlert = false;
    
    let healthStore = HKHealthStore()
    
    func onHealthAppSync() {
        
        HealthKitSetupAssistant.authorizeHealthKit { (authorized, error) in
            
            
            DispatchQueue.main.async {
                self.isLoading = true;
            }
        
            guard authorized else {
                
                let baseMessage = "healthAuthFaild";
                
                if let error = error {
                    //print("\(baseMessage). Reason: \(error.localizedDescription)")
                    
                    DispatchQueue.main.async {
                        self.isLoading = false;
                        self.isShowingAlert = true;
                        self.errorMessage = "\(baseMessage). Reason: \(error.localizedDescription)";
                    }
                    
                } else {
                    //print(baseMessage)
                    DispatchQueue.main.async {
                        self.isLoading = false;
                        self.isShowingAlert = true;
                        self.errorMessage = "\(baseMessage)";
                    }
                    
                }                
                return
            }
            HealthKitSetupAssistant.checkPermissionListEnableOrNot { success in
                
                if(success){
                    
                    DispatchQueue.main.async {
                        
                        self.isSuccess = true
                        
                    }
                    
                }else {
                    
                    DispatchQueue.main.async {
                        
                        self.isLoading = false;
                        self.isShowingAlert = true;
                        self.errorMessage = "healAuthFaildEnablePermission";
                    }
                }
            }
        }
    }
    
    init() {
        
    }
    
}

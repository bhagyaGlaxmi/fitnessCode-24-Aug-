//
//  AuthenticationView.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import SwiftUI
import HealthKit

struct AuthenticationView: View {
    @ObservedObject var viewModel = AuthenticationViewModel()
    var body: some View {
        
        Form{
            NavigationStack{
                
                VStack(alignment: .center, spacing: CGFloat.theme.mediumSpacing){
                    
                    Spacer()
                   
    //                Image("logo")
    //                    .resizable()
    //                    .scaledToFit()
    //                    .frame(width: CGFloat.theme.logoWidth, height: CGFloat.theme.logoHeight).padding([.top], CGFloat.theme.extraLargeSpacing)
    //
    //                Text("welcomeLogin").foregroundColor(Color.theme.brand).padding([.top,.bottom], CGFloat.theme.largeSpacing)
    //
                    
                    
                    if viewModel.isLoading == false {
                        
                        Button("syncWithHealth") {
                            
                            viewModel.onHealthAppSync()
                            
                        }.buttonStyle(CustomButtonStyle())
                        
                        
                    }else {
                        
                        ProgressView("loading")
                    }
                    
                    
                    Spacer()
                    
                }.alert( LocalizedStringKey(viewModel.errorMessage), isPresented: $viewModel.isShowingAlert) {
                    
                }.padding(CGFloat.theme.mediumSpacing).navigationDestination(isPresented: $viewModel.isSuccess) {
                    //HomeView().navigationBarBackButtonHidden(true)
                    HomeMenuView()
                        .navigationBarHidden(true)
                }.toolbar{
                    CustomToolBar(title : "syncData", transparency: false)
                }.onAppear{
                    self.viewModel.onHealthAppSync()
                }
                
                
            }
        }
        
    }
}

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView()
    }
}

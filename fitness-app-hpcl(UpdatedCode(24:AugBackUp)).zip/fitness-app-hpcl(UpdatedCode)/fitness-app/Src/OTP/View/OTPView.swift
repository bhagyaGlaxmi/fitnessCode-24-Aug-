//
//  OTPView.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import SwiftUI

struct OTPView: View {
   // @ObservedObject var viewModel = OTPViewModal()
    @ObservedObject var viewModel: OTPViewModel
    var body: some View {
        
        NavigationStack{
            
            VStack(alignment: .center, spacing: CGFloat.theme.mediumSpacing){
                
                
                Spacer()
                
                Text(LocalizedStringKey("otpHint")).padding([.top], CGFloat.theme.smallSpacing)
                
                Text(LocalizedStringKey("registeredMobileNumber \(viewModel.mobileNumber)")  )
                
                FloatingTextField(placeholder: LocalizedStringKey("verificationCode"), errorMessage: viewModel.otpErrorMessage,  isSecureTextEntry: false,  text: $viewModel.otp, keyboardType: UIKeyboardType.numberPad) { value in
                    
                    viewModel.isOTPChanged(value: value)
                    
                }.padding([.top], CGFloat.theme.largeSpacing)
                
                
                if  viewModel.isLoading == false  {
                    
                    Button("verify") {
                        
                        viewModel.validateOTP(request: ValidateOTPRequest(mobileNo: viewModel.mobileNumber, otp: viewModel.otp, app_type: Constants.appType, app_version: Constants.appVersion, firebase: UserDefaults.standard.pushNotificationFirebaseToken))
                        
                    }.buttonStyle(CustomButtonStyle()).disabled(!viewModel.isValidMobileNumber).padding([.top], CGFloat.theme.largeSpacing)
                    
                    
                }else {
                    
                    ProgressView("loading")
                }
                
              
                //ProgressView("loading")
                
                Spacer()
                
            }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
                
            }.padding(CGFloat.theme.mediumSpacing).navigationDestination(isPresented: $viewModel.isSuccess) {
                AuthenticationView().navigationBarBackButtonHidden(true)
            }.toolbar{
                CustomToolBar(title : "otpScreen", transparency: false)
            }            
            
        }
        
        
        
    }
}

//
//  OTPViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import SwiftUI

class OTPViewModel: ObservableObject {
    
     //var mobileNumber: String = ""
     var mobileNumber: String


    @Published var otp : String = ""
    
    @Published var otpErrorMessage = ""
    @Published var isLoading = false
    @Published var isSuccess = false
    
    @Published var isValidMobileNumber = false
    
    @Published  var isShowingAlert = false
    
    @Published  var errorMessage = ""
    
    
    func validateOTP(){
      
        DispatchQueue.main.async {
            UserDefaults.standard.loginStatus = true;
            self.isSuccess = true;
        }
        
    }
    
    func isOTPChanged(value : String)  {
        
        otp = value;
        
        if value.isValidOTP() {
            otpErrorMessage =  ""
            isValidMobileNumber = true;
        } else {
            isValidMobileNumber = false;
            otpErrorMessage =  "invalidOTP"
        }
        
        
    }
    
    init(mobileNumber: String) {
            self.mobileNumber = mobileNumber
        }
    
    func validateOTP(request: ValidateOTPRequest)
    
    {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.callValidateOTP(parameters: request.dictionary ?? [:]) { response in
            if let response = response {
                print("successshow \(response)")
                
                DispatchQueue.main.async {
                    UserDefaults.standard.loginStatus = true;
                    UserDefaults.standard.name = response.name;
                    UserDefaults.standard.email = response.emailid;
                    //UserDefaults.standard.token = response.token;
                    
                    UserDefaults.standard.mobile = self.mobileNumber;
                    
                    //print("pmeStatus \(response.pmeStatus)")
                    
                    UserDefaults.standard.pme = response.pmeStatus == "Y" ? true : false;
                    UserDefaults.standard.empNo = response.encrypted_empNo;

                    UIPreferences.setPreference(token: response.token, preference: response.preference, heart_point: response.heart_point, calorie: response.calorie, distance: response.distance, move_minute: response.move_minute, stepGoal: response.stepGoal, heartGoal: response.heartGoal)
                    print("HEART POINTS",response.heart_point!)
                    print("HEART goals",response.heartGoal!)
                    print("HEART Prefernces",response.preference!)
                    print("DISTANCE",response.distance!)
                    print("EMPNO",UserDefaults.standard.empNo)
                    print("EMP_NOLD",response.encrypted_empNo)
                    
//                    UserDefaults.standard.isHeartPoint = response.heart_point == "Y" ? true : false;
//                    UserDefaults.standard.isPreferences = response.preference == "Y" ? true : false;
//                    UserDefaults.standard.isCalories = response.calorie == "Y" ? true : false;
//                    UserDefaults.standard.isDistance = response.distance == "Y" ? true : false;
//                    UserDefaults.standard.isMoveMinute = response.move_minute == "Y" ? true : false;
//
//                    UserDefaults.standard.stepsADay = response.stepGoal;
//                    UserDefaults.standard.heartPointADay = response.heartGoal;
                    
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                }
            }
        }
    failure: { error in
        
        //print("error \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
        
    }
    }
    
}

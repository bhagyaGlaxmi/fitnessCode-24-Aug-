//
//  SetGoalViewModal.swift
//  fitness-app
//
//  Created by Babu Lal on 21/12/22.
//

import Foundation
import SwiftUI

class SetGoalViewModel: ObservableObject {
    
    @Published var stepsADay : String = ""
    @Published var isStepsADayValid = false
    @Published var stepsADayError = ""
    
    @Published var heartPointADay : String = ""
    @Published var isHeartPointADayValid = false
    @Published var heartPointADayError = ""
    
    @Published var isLoading = false
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false

    
    @Published var isSuccess = false

    
    func setDefaultData(){
        
        stepsADay = UserDefaults.standard.stepsADay!
        heartPointADay = UserDefaults.standard.heartPointADay!
        
        isStepADayChange(value:stepsADay);
        isHeartPointADayChange(value: heartPointADay);
    }
    
    
    func isStepADayChange(value : String)  {
        
        stepsADay = value;
        
        if value.isValidStepsADay() {
            stepsADayError =  ""
            isStepsADayValid = true;
        } else {
            isStepsADayValid = false;
            stepsADayError =  "invalid"
        }
        
    }
    
    func isHeartPointADayChange(value : String)  {
        
        heartPointADay = value;
        
        if value.isValidHeartPointADay() {
            heartPointADayError =  ""
            isHeartPointADayValid = true;
        } else {
            heartPointADayError =  "invalid"
            isHeartPointADayValid = false;
        }
        
    }
    
   
    
    func onSuccess(success:Bool){
        isSuccess = success;
        if(isSuccess){
            
        }
    }
    
    func setGoalApiCall(request: SetGoalRequest) {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.setGoal(parameters: request.dictionary ?? [:]) { response in
            if response != nil {
                print("success \(String(describing: response))")
                
                
                DispatchQueue.main.async {
                  
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                    UserDefaults.standard.heartPointADay = self.heartPointADay;
                    UserDefaults.standard.stepsADay = self.stepsADay
                    
                    self.errorMessage = "successfullyUpdatedGoal"
                    self.isShowingAlert = true;
                    
                    
                }
            }
        }
    failure: { error in
        
        print("error \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
        
        
    }
    }
    
}

//
//  SetGoalResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import Foundation

struct SetGoalResponse: Codable {
    var status: String?
}

//
//  GraphicalView.swift
//  fitness-app
//
//  Created by Babu Lal on 19/12/22.
//

import SwiftUI


struct GraphicalView: View {
    
    //var energyBurnedAvg = 0;
    var energyBurnedToday = 0.0;
    var heartRate = 0;
    var walkingDistance = 0.0;
    var dayStepCount = 0.0;
    var percentageDayStepCount = 0.0;
   //func  success : @escaping ((Bool) -> Void)
    var onStepClick : () -> ()
    var onDistanceClick : () -> ()
    var onCaloriesClick : () -> ()

    

   
    var body: some View {
            
        VStack{
            
            VStack{
                
                ZStack(alignment: .center){
                    
                  /*  if(UserDefaults.standard.isHeartPoint) {
                        CircularProgressView(progress: 0.1, color: Color.theme.heartRate)
                            .frame(width: 210, height: 210)
                    }*/
                  
                    
                    CircularProgressView(progress: percentageDayStepCount/100,color: Color.theme.steps)
                        .frame(width: 150, height: 150)
                    
                    VStack(alignment: .center){
                        Text("\(Int(dayStepCount))")
                            .font(Font.theme.title).foregroundColor(Color.theme.steps)
                        
                        if(UserDefaults.standard.isHeartPoint) {
                            Text("\(heartRate)")
                                .font(Font.theme.title).foregroundColor(Color.theme.heartRate)
                        }
                       
                    }
                 
                }
               
            }.padding([.top,.bottom], CGFloat.theme.mediumSpacing)
            
        
            
           /* PieChartView(values: [dayStepCount,  Double(UserDefaults.standard.stepsADay) ?? 0], colors: [Color.theme.steps, Color.theme.lightGrey], names: ["Steps", "Remaining Target"], backgroundColor: Color.theme.background, innerRadiusFraction: 0.6, hint : "Target", heartRate: Double(heartRate)) */
                        
            HStack(alignment: .center){
                Spacer()
                
                HStack{
                    Image(systemName: "figure.stair.stepper").resizable().frame(width: CGFloat.theme.dashboardIconSize, height: CGFloat.theme.dashboardIconSize) .foregroundColor(Color.theme.brandPrimary)
                    Text(LocalizedStringKey("steps"))
                        .font(Font.theme.body).foregroundColor(Color.theme.steps)
                }.onTapGesture {
                    self.onStepClick()
                }
              
                
                if(UserDefaults.standard.isHeartPoint) {
                    
                    
                    Image(systemName: "heart.fill").resizable().frame(width: CGFloat.theme.dashboardIconSize, height: CGFloat.theme.dashboardIconSize) .foregroundColor(Color.theme.heartRate)
                    Text(LocalizedStringKey("heartRate"))
                        .font(Font.theme.body).foregroundColor(Color.theme.heartRate)
                }
                Spacer()
            }.padding(.top, CGFloat.theme.mediumSpacing)
            
            HStack{
                if(UserDefaults.standard.isCalories){
                    VStack(alignment: .center){
                        HStack{
                            Image(systemName: "flame").resizable().frame(width: CGFloat.theme.dashboardIconSize, height: CGFloat.theme.dashboardIconSize) .foregroundColor(Color.theme.brandPrimary)
                         //   Text("\(energyBurnedToday)")
                                .font(Font.theme.title).foregroundColor(Color.theme.brandPrimary)
                            
                            Text("\(String(format: "%.2f", energyBurnedToday))")
                                .font(Font.theme.title).foregroundColor(Color.theme.brandPrimary)
                        }
                        
                        Text("kcal")
                            .font(Font.theme.body)
                        
                    }.onTapGesture {
                        self.onCaloriesClick()
                    }
                }
               
                
                if(UserDefaults.standard.isDistance) {
                    VStack(alignment: .center){
                        
                        HStack{
                            Image(systemName: "figure.walk").resizable().frame(width: CGFloat.theme.dashboardIconSize, height: CGFloat.theme.dashboardIconSize) .foregroundColor(Color.theme.brandPrimary)
                            
                            Text("\(String(format: "%.2f", walkingDistance/1000))")
                                .font(Font.theme.title).foregroundColor(Color.theme.brandPrimary)
                        }
                        
                        Text("km")
                            .font(Font.theme.body)
                        
                        
                    }.padding(.leading, CGFloat.theme.mediumSpacing).onTapGesture {
                        self.onDistanceClick()
                    }
                }
                
              
                
            }.padding(.top, CGFloat.theme.largeSpacing).padding(.bottom, CGFloat.theme.largeSpacing)
            
            
            
            
        }
//        .navigationDestination(isPresented: $stepsClick) {
//            StepsResportView().navigationBarBackButtonHidden(false)
//        }
            
        
        
    }
           
}

//
//  HomeMenuView.swift
//  Test
//
//  Created by Babu Lal Choudhary on 27/03/22.
//

import SwiftUI

struct HomeMenuView: View {
    
    @State private var isShowing = false;

    
    var body: some View {
        NavigationView {
           
            ZStack {

                if isShowing {
                    SideMenuView(isShowing: $isShowing)
                }
                HomeMenuSubView()

                    .cornerRadius(isShowing ? 20 : 10)
                    .offset(x: isShowing ? 300.0 : 0.0, y: isShowing ? 44.0 : 0.0)
                        .scaleEffect(isShowing ? 0.8 : 1.0)
                        .navigationBarItems(leading: Button(action: {

                            withAnimation(.spring()){
                                isShowing.toggle()
                            }

                    }, label: {
                        Image(systemName: "list.dash")
                        .foregroundColor(.blue)
                    }))


            }.onAppear{
                isShowing = false;
            }
            .toolbar{  CustomToolBar(title : "appName", transparency: false)}
          
        }
    }
}

struct HomeMenuView_Previews: PreviewProvider {
    static var previews: some View {
        HomeMenuView()
    }
}

struct HomeMenuSubView: View {
    var body: some View {
        ZStack {
           HomeView()
        }

    }
}


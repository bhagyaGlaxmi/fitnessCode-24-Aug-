//
//  StepscountView.swift
//  fitness-app
//
//  Created by pundarik rajkhowa on 23/02/23.
//

import SwiftUI

struct StepscountView: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    @State  var isStepClick = false
    @State  var isDistanceClick = false
    @State  var isCaloriesClick = false
    
    
    var body: some View {
        
        Form(){
            NavigationStack{
                VStack{
                    if(viewModel.isLoading == false){
                        GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate:viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount:viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick,onCaloriesClick: self.onCaloriesClick)
                        BarChartView(data : viewModel.stepCountData, dataType: .steps)
                        
                        
                    }else {
                        ProgressView("loading")
                    }
                }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
                    
                }
                
                
            }
            
            .onAppear(perform: {
               
                viewModel.getHeartRate()
                viewModel.getHealthData()
                                
            }).navigationDestination(isPresented: $isStepClick) {
                ReportView(viewModel: ReportViewModel(dataType: .steps, title: "stepsReport")).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isDistanceClick) {
                ReportView(viewModel: ReportViewModel(dataType: .distance, title: "distanceReport")).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isCaloriesClick) {
                ReportView(viewModel: ReportViewModel(dataType: .energy, title: "caloriesReport")).navigationBarBackButtonHidden(false)
            }
          
//            VStack{
//                WebUIView(viewModel: WebViewModel(url: "https://medclaim.hpcl.co.in/medclaim/pme_new.jsp?c=675g19kGyol8eZQ/vqH2SQ=="))
//                    .frame(width: 400, height: 400)
//            }
            
            
        }.toolbar{
            CustomToolBar(title : "Steps Count", transparency: false)
        }
       
    }
    
    func onStepClick() {
       
        isStepClick = true;
           
    }
    
    func onDistanceClick() {
       
        isDistanceClick = true;
           
    }
    
    func onCaloriesClick() {
       
        isCaloriesClick = true;
           
    }
    
}












struct StepscountView_Previews: PreviewProvider {
    static var previews: some View {
        StepscountView()
    }
}

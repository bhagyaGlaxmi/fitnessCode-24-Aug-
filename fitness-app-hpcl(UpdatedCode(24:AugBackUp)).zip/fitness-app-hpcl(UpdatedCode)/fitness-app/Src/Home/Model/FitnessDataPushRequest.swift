//
//  FitnessDataPushRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation
struct FitnessDataPushRequest: Codable {
    var api_date: String?
    var datatype: String?
    var gmailid: String?
    var token: String?
    var step_count: String?
    var distance: String?
    var calories: String?

}



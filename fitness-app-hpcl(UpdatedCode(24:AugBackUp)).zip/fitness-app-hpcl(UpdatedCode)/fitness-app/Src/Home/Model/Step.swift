//
//  Step.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation

struct StepData : Codable, Identifiable {
    //var id: ObjectIdentifier
    var id: Int
    var date: Date
    var count: Int
    var distance: Double

    init(id: Int, date: Date, count : Int, distance : Double) {
        self.id = id
        self.date = date
        self.count = count
        self.distance = distance
    }
}


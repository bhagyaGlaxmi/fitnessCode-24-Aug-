//
//  LastUpdatedDateRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation

struct LastUpdatedDateRequest: Codable {
    var emailid: String?
    var token: String?

}

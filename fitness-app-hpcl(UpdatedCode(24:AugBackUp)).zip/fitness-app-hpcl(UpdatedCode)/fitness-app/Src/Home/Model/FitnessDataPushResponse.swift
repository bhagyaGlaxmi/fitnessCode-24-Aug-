//
//  FitnessDataPushResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation
struct FitnessDataPushResponse: Codable {
    var status: String?
}

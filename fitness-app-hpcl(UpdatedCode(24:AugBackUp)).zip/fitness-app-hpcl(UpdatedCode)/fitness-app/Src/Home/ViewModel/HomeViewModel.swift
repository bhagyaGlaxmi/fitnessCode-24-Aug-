//
//  HomeViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
import HomeKit
import SwiftUI
import HealthKit
import Alamofire



class HomeViewModel: ObservableObject {
    
    @Published var isLoading = false;
    @Published var isSuccess = false;
    
    
    @Published var stepList: [StepData] = [];
    
    @Published var heartRate = 0;
    
    @Published var energyBurnedToday = 0.0;
    @Published var walkingDistance = 0.0;
    @Published var dayStepCount = 0.0;
    @Published var percentageDayStepCount = 0.0;
    
    
    @Published var stepCountData: [[Date: Double]] = []
    @Published var distanceData: [[Date: Double]] = []
    @Published var energyData: [[Date: Double]] = []
    
    
    @Published var stepCountDataUp: [[Date: Double]] = []
    @Published var distanceDataUp: [[Date: Double]] = []
    @Published var energyDataUp: [[Date: Double]] = []
    
    
    @Published var stepCountDataUpload: [FitnessDataPushRequest] = []
    
    
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false
    
    @Published  var lastUpdatedDateResponse : LastUpdatedDateResponse?
    
    
    func getHeartRate(){
        
        print("isPreferences \(UserDefaults.standard.isPreferences)")
        
        GetHeartRate().fetchLatestHeartRateSample( completion: { (success, heartRate, error) in
            
            if(success == true){
                //print("heartRate \(heartRate)")
                DispatchQueue.main.async {
                    
                    self.heartRate = heartRate ?? 0
                    
                }
            }else {
                //print("error \(String(describing: error))")
                
                DispatchQueue.main.async {
                    
                    //self.isLoading = false;
                    self.isShowingAlert = true;
                    self.errorMessage = String(describing: error);
                    
                    
                }
            }
            
        })
    }
    
    
    func getHealthData(){
        
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        
        
        GetHealthData().fetchDataFor(numberOfDays: 7, dataType: .distance) { [weak self] (response, error) in
            
            guard (error == nil) else {
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                    
                    
                }
                
                return
            }
            if let healthKitData = response {
                
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    //self?.walkingDistanceData = healthKitData;
                    //print("walkingDistanceData\(healthKitData)")
                    self?.distanceData = healthKitData;
                    
                    self?.walkingDistance = healthKitData[healthKitData.count - 1].values.first!;
                    //var sum = 0
                    //                    self?.walkingDistance = 0.0;
                    //                    for value in healthKitData {
                    //                        // sum += value
                    //
                    //                        let values = Double(value.values.first!);
                    //                        self?.walkingDistance = values;
                    //
                    //                        //print("walkingDistance\(self?.walkingDistance)")
                    //                    }
                    
                }
                
            }
        }
        
        GetHealthData().fetchDataFor(numberOfDays: 7, dataType: .steps) { [weak self] (response, error) in
            
            guard (error == nil) else {
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    self?.stepCountData = healthKitData;
                    
                   // print("stepCountData\(self?.stepCountData)")
                    
                    if(healthKitData.count>0){
                        self?.dayStepCount = Double((healthKitData[healthKitData.count-1]).values.first!);
                        
                        if(self?.dayStepCount != nil){
                            if(Double(UserDefaults.standard.stepsADay!)! > (self?.dayStepCount)! ){
                                
                                self?.stepGoalCalculate()
                                
                            }else {
                                UserDefaults.standard.stepsADay = String(self!.dayStepCount);
                                
                                self?.stepGoalCalculate()
                            }
                        }
                        
                        
                    }
                    
                    
                    //                    for value in healthKitData {
                    //                        // sum += value
                    //
                    //                        let values = Double(value.values.first!);
                    //                        self?.totalStepCount += values;
                    //
                    //                        //print("walkingDistance\(self?.walkingDistance)")
                    //                    }
                }
            }
        }
        
        
        GetHealthData().fetchDataFor(numberOfDays: 7, dataType: .energy) { [weak self] (response, error) in
            
            guard (error == nil) else {
                //print("CaloriesDataError \(error)")
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                //print("CaloriesData \(healthKitData)")
                
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    //self?.stepCountData = healthKitData;
                    self?.energyData = healthKitData
                    
                    self?.energyBurnedToday = healthKitData[healthKitData.count - 1].values.first!;
                   
                }
            }
        }
        
        
        
        lastUpdatedDateApiCall(request: LastUpdatedDateRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token))
        
    }
    
    

    
    
    func stepGoalCalculate(){
        
        let total = Double(UserDefaults.standard.stepsADay!)!
        let achieve = self.dayStepCount;
        
        self.percentageDayStepCount = (achieve / total) * 100;
                
        //print("GoalPercentage \(percentageDayStepCount)");
    }
    
    
    /*
     Last updated Date
     */
    func lastUpdatedDateApiCall(request: LastUpdatedDateRequest) {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.callLastUpdatedDate(parameters: request.dictionary ?? [:]) { response in
            if let response = response {
                print("success LastDate \(response)")
                
                DispatchQueue.main.async {
                    self.lastUpdatedDateResponse = response;
                    self.isLoading = false;
                    self.isSuccess = true;
                    //self.dataPreparingForUpload();
                    self.uploadDataCheck();
                }
            }
        }
    failure: { error in
        
        print("error LastDate \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
        
        
    }
        
    }
    
    func uploadDataCheck(){
        let lastUpdatedDate = self.lastUpdatedDateResponse?.Last_Date;
        
        guard lastUpdatedDate != nil else {
            return
        }
        
        //var lastUpdatedDate = "2022-12-19"
        
        //let lastUpdatedDateDate : Date? = lastUpdatedDate!.toDate(dateFormat: DateFormat.local)
        
        let yesterdayDate = Date().dayBefore.toString(dateFormat: DateFormat.local)
        
        //print("yesterdayDate \(yesterdayDate)")
        
        let lastUpdatedDateDate =  ( lastUpdatedDate! + " 18:30:00 +0000")
        
        //print("startDateValue_Update_1 \(lastUpdatedDateDate)")

        
        let startDateValue = lastUpdatedDateDate.toDate(dateFormat: DateFormat.localDateTime)
        
        //print("startDateValue_Update \(startDateValue)")
       // print("endDate_Update \(Date())")

        
        if(yesterdayDate != (lastUpdatedDate!)){
            
            DispatchQueue.main.async {
                self.isLoading = true;
            }
            
            
            GetHealthData().fetchDataForCustomDate(dataType: .distance, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                        
                        
                    }
                    
                    return
                }
                if let healthKitData = response {
                    
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        //self?.walkingDistanceData = healthKitData;
                        //print("walkingDistanceData\(healthKitData)")
                        self?.distanceDataUp = healthKitData;
                        
                        //print("distanceDataUp\(self?.distanceDataUp)")
                        
                        
                        
                    }
                    
                    
                }
            }
            
            GetHealthData().fetchDataForCustomDate(dataType: .steps, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    DispatchQueue.main.async {
                        
                        self!.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                    }
                    
                    return
                }
                if let healthKitData = response {
                    
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        self?.stepCountDataUp = healthKitData;
                        
                       // print("stepCountData\(self?.stepCountData)")
                        //print("stepCountDataUp\(self?.stepCountDataUp)")

                     
                        
                 
                    }
                }
            }
            
            
            GetHealthData().fetchDataForCustomDate(dataType: .energy, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    //print("CaloriesDataError \(error)")
                    DispatchQueue.main.async {
                        
                        self!.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                    }
                    
                    return
                }
                if let healthKitData = response {
                    //print("CaloriesData \(healthKitData)")
                    
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        //self?.stepCountData = healthKitData;
                        self?.energyDataUp = healthKitData
                        
                        //print("energyDataUp\(String(describing: self?.energyDataUp))")
                        
                        self?.dataPreparingForUpload();
                        
                    
                        
                        
                    }
                }
            }
            
            
         
          
            
        }
    }
    
    func dataPreparingForUpload(){
        
        let lastUpdatedDate = self.lastUpdatedDateResponse?.Last_Date;
        
        guard lastUpdatedDate != nil else {
            return
        }
        
        //var lastUpdatedDate = "2022-12-19"
        
        //let lastUpdatedDateDate : Date? = lastUpdatedDate!.toDate(dateFormat: DateFormat.local)
        
        let yesterdayDate = Date().dayBefore.toString(dateFormat: DateFormat.local)
        
        //print("yesterdayDate \(yesterdayDate)")
        //print("lastUpdatedDate \(lastUpdatedDate)")
        
        
        if(yesterdayDate != (lastUpdatedDate!)){
          
            //print("Data Updating...")
            //print("stepCountDataUp_1 \(stepCountDataUp)")
            
            for (value) in stepCountDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
                //print("dateDate \(dateDate)")
                //print("dateStr \(dateStr)")
                
                if(dateStr > lastUpdatedDate!){
                    
                    self.stepCountDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeStepCount, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, step_count:  String(describing: value.values.first!)))
                    
                }
                
            }
            
            for (value) in distanceDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
                if(dateStr > lastUpdatedDate!){
                    
                    self.stepCountDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeDistance, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, distance:  String(describing: (value.values.first!) )))
                    
                    
                }
            }
            
            for (value) in energyDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
                if(dateStr > lastUpdatedDate!){
                    
                    self.stepCountDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeEnergy, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, calories:  String(describing: value.values.first! )))
                    
                    
                }
            }
            
            if(self.stepCountDataUpload.count > 0){
                //print("jsonData \(self.stepCountDataUpload.dictionaryArray)")
                
                self.stepDataPushApiCall(request:self.stepCountDataUpload)
                
                //let jsonData = self.stepCountDataUpload.dictionaryArray
                
            }
            
            
        }else {
            //print("Data already updated yesterday")
        }
        
        
    }
    
    
    /*
     Push Fitness Steps Data
     */
    func stepDataPushApiCall(request: [FitnessDataPushRequest]) {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.finessDataPush(parameters: request) { response in
            if let response = response {
                print("success Push \(response)")
                
                DispatchQueue.main.async {
                    
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                }
            }
        }
    failure: { error in
        
        print("error Push \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
        
        
    }
        
        
    }
    
    
    
    
}

//
//  SetPreferencesView.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import SwiftUI

struct SetPreferencesView: View {
    @ObservedObject var viewModel = SetPreferencesViewModel()
    
    
    
    var body: some View {
       
               

        Form{
            
            //Toggle(LocalizedStringKey("heartPoints"), isOn: $viewModel.isHeartPoints).padding()
            Toggle(LocalizedStringKey("calorie"), isOn: $viewModel.isCalorie).padding()
            Toggle(LocalizedStringKey("distance"), isOn: $viewModel.isDistance).padding()
            //Toggle(LocalizedStringKey("moveMinute"), isOn: $viewModel.isMoveMinute).padding()
            

            if  viewModel.isLoading == false  {
                
                Button("submit") {
                    
                    //viewModel.isSubmitChange()
                    viewModel.setPreferenceApiCall()
                    
                }.buttonStyle(CustomButtonStyle()).padding([.top,.bottom], CGFloat.theme.mediumSpacing)
                
                
            }else {
                
                ProgressView("loading")
            }
        }.alert( LocalizedStringKey(viewModel.errorMessage), isPresented: $viewModel.isShowingAlert) {
            
        }.toolbar{
            CustomToolBar(title : "setPreferences", transparency: false)
        }.onAppear(){
            viewModel.loadLocalData()
        }
    }
}



//
//  SetPreferencesResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import Foundation

struct SetPreferencesResponse: Codable {
    var status: String?
}

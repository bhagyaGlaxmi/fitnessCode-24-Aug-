//
//  SetPreferencesRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import Foundation

struct SetPreferencesRequest: Codable {
    var emailid: String?
    var token: String?
    var heart_point: String?
    var calorie: String?
    var distance: String?
    var move_minute: String?

}



//
//  ReportViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 29/12/22.
//

import Foundation
import Foundation
import HomeKit
import SwiftUI
import HealthKit
import Alamofire

class ReportViewModel: ObservableObject {
    
    @Published var isLoading = false;
    @Published var isSuccess = false;
    
    @Published var data: [[Date: Double]] = []
    
    @Published var days: [Date] = []

    
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false
    
    @Published var dataType : DataType = .steps
    @Published  var title = ""

    
    
    init(dataType: DataType, title : String) {
            self.dataType = dataType
        self.title = title
        }
    
    func onChangeDate(){
        //print("days \(self.days)");
        if(self.days.count > 0){
            getHealthData()
        }else {
            
            guard let firstWeek = Calendar(identifier: .gregorian).dateInterval(of: .weekOfMonth, for: Date()),
                    let lastWeek = Calendar(identifier: .gregorian).dateInterval(of: .weekOfMonth, for: firstWeek.end - 1)
            else {
                return;
            }
                
            let dateInterval = DateInterval(start: firstWeek.start, end: lastWeek.end)
            self.days = Calendar(identifier: .gregorian).generateDays(for: dateInterval);
            
            getHealthData();
        }
    }
    
   
    
  

    func getHealthData(){
        
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        
        GetHealthData().fetchDataForCustomDate(dataType: dataType, startDateValue: days[0], endDateValue: days[days.count-1]) { [weak self] (response, error) in
            
            guard (error == nil) else {
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                    DispatchQueue.main.async {
                    
                    self?.data.removeAll()
                    self?.isLoading = false;
                    self?.data = healthKitData;
                    print("hEALTHdata \(String(describing: self?.data))")
                    
                }
            }
        }
        
    }
    
    
    
    
    
    
}

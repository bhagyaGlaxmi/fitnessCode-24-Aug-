//
//  DashboardView.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import SwiftUI

struct DashboardView: View {
    @ObservedObject var viewModel = DashboardViewModel()
   
    var body: some View {
        NavigationStack{
            
            VStack{
                Text("Coming Soon...")
               
            }.onAppear{
              //  HomeView()
               
            }.navigationDestination(isPresented: $viewModel.isSuccess) {
                HomeView(viewModel: HomeViewModel())
            }

            
        }
       
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
    }
}

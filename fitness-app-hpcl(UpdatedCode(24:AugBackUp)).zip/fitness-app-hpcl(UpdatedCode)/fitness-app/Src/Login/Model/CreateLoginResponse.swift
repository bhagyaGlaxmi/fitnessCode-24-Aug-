//
//  CreateLoginResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation

struct CreateLoginResponse: Codable {
    var status: String?;
   
}

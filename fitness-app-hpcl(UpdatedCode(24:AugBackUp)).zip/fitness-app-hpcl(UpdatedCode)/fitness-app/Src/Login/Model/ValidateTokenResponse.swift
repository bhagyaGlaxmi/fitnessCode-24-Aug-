//
//  ValidateTokenResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 20/12/22.
//

import Foundation
struct ValidateTokenResponse: Codable {
    var token: String?;
    var preference: String?;
    var heart_point: String?;
    var calorie: String?;
    var distance: String?;
    var move_minute: String?;
    var stepGoal: String?;
    var heartGoal: String?;
   
}

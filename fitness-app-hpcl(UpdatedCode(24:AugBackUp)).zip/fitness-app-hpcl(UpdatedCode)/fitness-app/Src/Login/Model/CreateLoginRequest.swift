//
//  CreateLoginRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation

struct CreateLoginRequest: Codable {
    var mobileNo: String?
    var app_type: String?
    var app_version: String?

}

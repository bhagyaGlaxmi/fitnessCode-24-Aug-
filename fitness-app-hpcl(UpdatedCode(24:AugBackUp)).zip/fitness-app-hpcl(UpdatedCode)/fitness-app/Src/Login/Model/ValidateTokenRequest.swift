//
//  ValidateTokenRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 20/12/22.
//

import Foundation
import Foundation

struct ValidateTokenRequest: Codable {
    var emailid: String?
    var token: String?
    var mobileNo: String?
    var app_type: String?
    var app_version: String?
    var firebase: String?

}

//
//  LoginView.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import SwiftUI

struct LoginView: View {
    @ObservedObject var viewModel = LoginViewModel()
    
    @ObservedObject var viewModelUpdateCheck = UpdateCheckViewModel()
    var body: some View {
        
        NavigationStack{
            
            VStack(alignment: .center){
                
                Spacer()
                
                if viewModel.isLoadingToken == false {
                    
                    if(viewModel.isTokenValid){
                        Button {
                            viewModel.biometricAuthenticate()
                        } label: {
                            
                            VStack{
                        Text("Click here to unlock with your Passcode if biometric is not configured!")
                                Image(systemName: "faceid").resizable().frame(width: 48.0,height: 48.0)
                                Text(LocalizedStringKey("biometricAuth")).padding([.top], CGFloat.theme.mediumSpacing)
                               
                            }.padding([.top,.bottom], CGFloat.theme.mediumSpacing)
                                                        
                        }.buttonStyle(.bordered).controlSize(.large).padding([.top], CGFloat.theme.largeSpacing)
                    }else {
                        FloatingTextField(placeholder: LocalizedStringKey("mobileNumber"), errorMessage: viewModel.mobileNumberErrorMessage,  isSecureTextEntry: false,  text: $viewModel.mobileNumber, keyboardType: UIKeyboardType.numberPad) { value in
                            viewModel.isMobileNumberChanged(value: value)
                        }
                    
                        if  viewModel.isLoading == false  {
                            Button("login") {
                                viewModel.createLogin(request: CreateLoginRequest(mobileNo: viewModel.mobileNumber, app_type: Constants.appType, app_version: Constants.appVersion))
                            }.buttonStyle(CustomButtonStyle()).disabled(!viewModel.isValidMobileNumber).padding([.top], CGFloat.theme.largeSpacing)
                        }else {
                            
                            ProgressView("loading")
                        }
                    }
                    
                }else {
                    ProgressView("loading")
                }
                Spacer()
            }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
                
            }.padding(CGFloat.theme.mediumSpacing)
                .navigationDestination(isPresented: $viewModel.isSuccess) {
                    OTPView(viewModel: OTPViewModel(mobileNumber : viewModel.mobileNumber))
                    //HomeMenuView().navigationBarBackButtonHidden(true)
                    
                }.navigationDestination(isPresented: $viewModel.isUnlocked) {
                    AuthenticationView().navigationBarBackButtonHidden(true)
                    
                }.background(
                    Image("background")
                        .resizable().scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                ).toolbar{
                    CustomToolBar(title : "appName", transparency: false)
                }.onAppear{
                    
                    //LocalStorage.removeValue();
                    
                    self.viewModelUpdateCheck.retriveAppStoreVersion()
                    self.viewModel.getLocalData()
                    //self.viewModel.isMobileNumberChanged(value: "9494116895")
                }.alert(isPresented:$viewModelUpdateCheck.isCheckingVersion) {
                    Alert(
                        title: Text("Click to update latest verion of app from Appstore"),
                       
                        primaryButton: .destructive(Text("Update")) {
                            print("Deleting...")
                            if let url = URL(string: "https://apps.apple.com/app/hp-fitness/id1661748062") {
                                UIApplication.shared.open(url)
                            }
//                            Link("OK", destination: URL(string: "https://apps.apple.com/app/hp-fitness/id1661748062")!)
                            
                        },
                        secondaryButton: .cancel()
                    )
                }
//                .alert(Text("Click to update latest verion of app from Appstore"), isPresented: $viewModelUpdateCheck.isCheckingVersion, actions: {
//
//
//
//
//
//                    Link("OK", destination: URL(string: "https://apps.apple.com/app/hp-fitness/id1661748062")!)
//
//
//                }
//)

//            alert(Text("Please update the app latest version is avialable"), isPresented: $viewModelUpdateCheck.isCheckingVersion, presenting:DismissAction.self, actions: {
//
//                }
//
//
//                )
                
//                .alert(Text("Please update the app latest version is avialable"), isPresented: $viewModelUpdateCheck.isCheckingVersion, actions: {
//
//                   // Button<<#Label: View#>>(action: .cancel, label: Text("jhdjsh"))
//                })
                
                
//                .alert(Text("Please update the app version"), isPresented: $viewModelUpdateCheck.isShowingAlertAppStoreVersion, actions: {
////                                Button("Update", action: {
////                                    if let url = URL(string: "https://apps.apple.com/app/hp-fitness/id1661748062") {
////                                           UIApplication.shared.open(url)
////                                        }
////                                })
////                                Button("Cancel", role: .cancel, action: {
////
////                                })
//                            })
            

            
        }
    }
    
    
    struct LoginView_Previews: PreviewProvider {
        static var previews: some View {
            LoginView()
        }
    }
    
}

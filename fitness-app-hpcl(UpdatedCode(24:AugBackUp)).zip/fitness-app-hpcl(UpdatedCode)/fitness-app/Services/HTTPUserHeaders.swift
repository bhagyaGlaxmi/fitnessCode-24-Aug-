//
//  HTTPUserHeaders.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import Alamofire
class HTTPUserHeaders {
    var headers = HTTPHeaders()
    init() {
        
        let user = "lubeapp"
            let password = "Ds@Hpcl#1234"
            let credentialData = "\(user):\(password)".data(using: String.Encoding.utf8)!
            let base64Credentials = credentialData.base64EncodedString(options: [])
            //let headersData = ["Authorization": "Basic \(base64Credentials)"]
        //headers.add(name: "Content-Type", value: "application/json")
        headers.add(name: "Accept", value: "application/json")
        //headers.add(name: "Content-Type", value: "multipart/form-data")
        headers.add(name: "Content-Type", value: "application/x-www-form-urlencoded")
        
        
       
        headers.add(name: "Authorization", value: "Basic \(base64Credentials)")
    }
    
    func getBasicHTTPHeaders() -> HTTPHeaders {
        return headers
    }
    
//    func headers() -> HTTPHeaders {
//        headers.add(name: "Content-Type", value: "application/json")
//        headers.add(name: "Accept", value: "application/json")
//
//        return headers
//    }
    
    func headersWithAuthToken(authToken: String?) -> HTTPHeaders {
        headers.add(name: "Content-Type", value: "application/json")
        headers.add(name: "Accept", value: "application/json")
        headers.add(name: "Authorization", value: authToken ?? "")
        return headers
    }
    func headersWithApiKey(apiKey: String?) -> HTTPHeaders {
        headers.add(name: "Content-Type", value: "application/json")
        headers.add(name: "Accept", value: "application/json")
        headers.add(name: "Appian-API-Key", value: apiKey ?? "")
        return headers
    }
    
    func headersWithImage() -> HTTPHeaders {
        headers.add(name: "Content-Type", value: "image/jpeg")
        headers.add(name: "Accept", value: "application/json")
        return headers
    }
}

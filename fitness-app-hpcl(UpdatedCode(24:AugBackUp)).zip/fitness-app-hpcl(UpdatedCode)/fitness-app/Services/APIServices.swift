//
//  APIServices.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import Foundation
import Alamofire

struct APIServices {
    public static let shared = APIServices()

    func callCreateLogin(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: CreateLoginResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {
      
        APIManager.shared.callAPI(serverURL: SeriveURL(path: .login).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
           
            
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(CreateLoginResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func callValidateOTP(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: ValidateOTPResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPI(serverURL: SeriveURL(path: .validateOTP).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(ValidateOTPResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func callValidateToken(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: ValidateTokenResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPI(serverURL: SeriveURL(path: .validateToken).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(ValidateTokenResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func callLastUpdatedDate(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: LastUpdatedDateResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPI(serverURL: SeriveURL(path: .lastUpdatedDate).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(LastUpdatedDateResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func finessDataPush(queryItems: [URLQueryItem]? = nil, parameters: [FitnessDataPushRequest], success: @escaping (_ result: FitnessDataPushResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPIArray(serverURL: SeriveURL(path: .fitnessDataPush).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters.dictionaryArray, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(FitnessDataPushResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func setGoal(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: SetGoalResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPI(serverURL: SeriveURL(path: .updateGoal).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(SetGoalResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func setPreferences(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: SetPreferencesResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {

        APIManager.shared.callAPI(serverURL: SeriveURL(path: .updatePreference).url, queryItems: queryItems, method: .post, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            do {
                if let data = response.data {
                    let dataResponse = try JSONDecoder().decode(SetPreferencesResponse.self, from: data)
                    success(dataResponse)
                }
            } catch {
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            failure(FailureMessage(error))
        })
    }
    
    func callAppStoreVersionCheck(queryItems: [URLQueryItem]? = nil, parameters: Parameters? = nil, success: @escaping (_ result: UpdateCheckResponse?) -> Void, failure: @escaping (_ failureMsg: FailureMessage) -> Void) {
      
        APIManager.shared.callAPIJson(serverURL: SeriveURL(path: .appStoreVersionCheck).urlAppStoreVersionCheck, queryItems: queryItems, method: .get, headers: HTTPUserHeaders().getBasicHTTPHeaders(), parameters: parameters, success: { response in
            print("VERSION URL",response)
            do {
                if let data = response.data {
                    print("dataAppStore \(data)")
                    let dataResponse = try JSONDecoder().decode(UpdateCheckResponse.self, from: data)
                    success(dataResponse)
                    print("dataAppStoreResponse \(dataResponse)")
                }
            } catch {
                //print("failureAppStore \(error)")
                failure(FailureMessage(error.localizedDescription))
            }

        }, failure: { error in
            //print("errorAppStore \(error)")
            failure(FailureMessage(error))
        })
    }
}

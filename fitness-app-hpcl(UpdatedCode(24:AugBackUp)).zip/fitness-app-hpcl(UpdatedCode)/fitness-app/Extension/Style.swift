//
//  Style.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation

import SwiftUI

struct CustomButtonStyle: ButtonStyle {
  
    
    func makeBody(configuration: ButtonStyle.Configuration) -> some View {
        MyButton( configuration: configuration )
    }
    
    struct MyButton: View {
        
       
        let configuration: ButtonStyle.Configuration
        @Environment(\.isEnabled) private var isEnabled: Bool
        var body: some View {
            configuration.label
           
                .padding(EdgeInsets(top: CGFloat.theme.mediumSpacing, leading: CGFloat.theme.extraLargeSpacing,bottom:CGFloat.theme.mediumSpacing, trailing: CGFloat.theme.extraLargeSpacing))
                .frame(maxWidth: .infinity)
               
                .background(isEnabled ? Color.theme.button : Color.theme.button.opacity(0.2))
                .foregroundColor(isEnabled ? Color.theme.buttonText : Color.theme.buttonText.opacity(0.3))

                //.foregroundColor(Color.theme.buttonText)
                .cornerRadius(CGFloat.theme.cornerRadius)
                .font(Font.theme.button)
                .scaleEffect(configuration.isPressed ? 1.2 : 1)
                .animation(.easeOut(duration: 0.2), value: configuration.isPressed
                )
        }
    }
}


import SwiftUI
@available(iOS 13.0, *)
extension TextAlignment {
    func getAlignment() -> Alignment {
        self == .leading ? Alignment.leading : self == .trailing ? Alignment.trailing : Alignment.center
    }
}




public extension View {
    func alert(isPresented: Binding<Bool>,
               title: String,
               message: String? = nil,
               dismissButton: Alert.Button? = nil) -> some View {

        alert(isPresented: isPresented) {
            Alert(title: Text(title),
                  message: {
                    if let message = message { return Text(message) }
                    else { return nil } }(),
                  dismissButton: dismissButton)
        }
    }
}


extension View {
 
    func navigationBarColor(_ backgroundColor: UIColor?) -> some View {
        self.modifier(NavigationBarModifier(backgroundColor: backgroundColor))
    }

}

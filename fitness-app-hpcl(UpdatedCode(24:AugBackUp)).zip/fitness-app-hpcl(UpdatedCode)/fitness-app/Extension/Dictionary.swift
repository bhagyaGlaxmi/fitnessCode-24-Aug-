//
//  Dictionary.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation
extension Dictionary {
    
    public subscript(i: Int) -> (key:Key, value:Value) {
        get {
            return self[index(startIndex,offsetBy: 1)]
        }
    }
}

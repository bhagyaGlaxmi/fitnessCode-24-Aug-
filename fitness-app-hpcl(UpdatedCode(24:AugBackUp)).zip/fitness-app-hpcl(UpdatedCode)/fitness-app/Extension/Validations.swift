//
//  Validations.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
extension String {
    var isValidEmail: Bool {
        let regularExpressionForEmail = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let testEmail = NSPredicate(format:"SELF MATCHES %@", regularExpressionForEmail)
        return testEmail.evaluate(with: self)
    }
    
    func isValidPhone() -> Bool {
        let regex = "^[1-9]{1}[0-9]{9}$"
        let phoneTest = NSPredicate(format:"SELF MATCHES %@", regex)
        return phoneTest.evaluate(with: self)
    }
    
    func isValidOTP() -> Bool {
        let regex = "^[0-9]{4}$"
        let phoneTest = NSPredicate(format:"SELF MATCHES %@", regex)
        return phoneTest.evaluate(with: self)
    }
    
    func isValidPassword() -> Bool {
        let regex = "(?=^.{8,}$)(?=.*\\d)(?=.*[!@#$%^&*]+)(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", regex)
        return passwordTest.evaluate(with: self)
    }
    
    func isValidStepsADay() -> Bool {
        let regex = "^[1-9]{1}[0-9]{2,4}$"
        let phoneTest = NSPredicate(format:"SELF MATCHES %@", regex)
        return phoneTest.evaluate(with: self)
    }
    
    func isValidHeartPointADay() -> Bool {
        let regex = "^[1-9]{1}[0-9]{1,2}$"
        let phoneTest = NSPredicate(format:"SELF MATCHES %@", regex)
        return phoneTest.evaluate(with: self)
    }
}

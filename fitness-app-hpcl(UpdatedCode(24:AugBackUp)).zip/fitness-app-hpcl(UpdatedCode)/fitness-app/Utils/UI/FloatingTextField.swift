//
//  FloatingTextField.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import SwiftUI

class TextBindingManager: ObservableObject {
    @Published var text = "" {
        didSet {
            if text.count > characterLimit && oldValue.count <= characterLimit {
                text = oldValue
            }
        }
    }
    let characterLimit: Int
    
    init(limit: Int = 10){
        characterLimit = limit
    }
}


struct FloatingTextField: View {
    var placeholder  : LocalizedStringKey = ""
    var errorMessage: String = ""
    
    // @Binding  var isValid: Bool
    
    var isSecureTextEntry: Bool
    
    
    
    @Binding var text: String
    var keyboardType: UIKeyboardType
    //@Binding  var editingChanged: (String) -> () = { _ in }
    
    var editingChanged: (String) -> () = { _ in }
    
  
    
    
    var body: some View {
  
        VStack(alignment: .leading){
            
            ZStack(alignment: .leading) {
                Text(placeholder)
                    .textFiledPlaceholder(text: self.text, errorMessage:self.errorMessage)
                
                
                
                ZStack (){
                    
                    if(isSecureTextEntry == true ) {
                        
                        
                        SecureField("", text: $text).onChange(of: text) {
                            //print($0) // You can do anything due to the change here.
                            // self.autocomplete($0) // like this
                            
                            //print("changing")
                            //userViewModel.isUsernameValidPublisher1(value: $0)
                            self.editingChanged($0)
                            
                            
                            
                        }.keyboardType(keyboardType).font(Font.theme.body)
                    }else {
                        TextField("", text: $text).onChange(of: text) {
                            //print($0) // You can do anything due to the change here.
                            // self.autocomplete($0) // like this
                            
                            //print("changing")
                            //userViewModel.isUsernameValidPublisher1(value: $0)
                            
                            self.editingChanged($0)
                            
                            
                        }.keyboardType(keyboardType).font(Font.theme.body)
                    }
                    
                }
                
                
                
            }
            .textFieldShape(text: self.text)
            
            Text(LocalizedStringKey(errorMessage)).foregroundColor(.red).font(Font.theme.body).padding([.leading], CGFloat.theme.largeSpacing)
        }
        
    }
}

extension View {
    func textFieldShape(text: String) -> some View {
        self.animation(.easeOut, value: text.isEmpty)
        //.foregroundColor(.black)
            .padding(.vertical, 5)
            .padding(.leading, CGFloat.theme.textFieldSpacing)
            .padding(.top, CGFloat.theme.textFieldSpacing)
            .padding(.bottom, CGFloat.theme.textFieldSpacing)
        
            //.frame(width: UIScreen.main.bounds.width - 40, height: 50)
        //.frame(height: 50)
        
            .background(
                RoundedRectangle(cornerRadius: CGFloat.theme.cornerRadius)
                //.stroke(text.isEmpty ? .gray.opacity(0.5) : .gray.opacity(0.9), lineWidth: 0.5)
                    .stroke(text.isEmpty ? Color.theme.border.opacity(0.9) : Color.theme.border.opacity(1.0), lineWidth: CGFloat.theme.lineWidth)
                    //.background(Color.theme.background)
                    .cornerRadius(CGFloat.theme.cornerRadius)
            )
    }
    
    func textFiledPlaceholder(text: String, errorMessage : String) -> some View {
        self.font(text.isEmpty ? .body : .subheadline)
        //.foregroundColor(isValid == true ? .primary : .red)
            .font(Font.theme.body)
            .padding(.horizontal, text.isEmpty ? 0 : 5)
            .padding(.top, text.isEmpty ? 0 : 10)
            .padding(.bottom, text.isEmpty ? 0 : 10)
            //.background(Color.theme.background)
           // .foregroundColor(text.isEmpty ? .primary: .secondary)
           
        
          
            .cornerRadius(CGFloat.theme.cornerRadius)
            .offset(y: text.isEmpty ? 0 : -23)
            .scaleEffect(text.isEmpty ? 1 : 0.9, anchor: .leading)
    }
}

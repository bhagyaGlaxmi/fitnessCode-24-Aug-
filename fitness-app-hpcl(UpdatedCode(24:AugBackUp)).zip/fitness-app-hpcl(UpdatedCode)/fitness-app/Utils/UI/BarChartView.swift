//
//  BarChartView.swift
//  fitness-app
//
//  Created by Babu Lal on 15/12/22.
//

import SwiftUI
import Charts


struct BarChartView: View {
    
    // let markColors = [Color.pink, .purple, .cyan, .brown, .orange, .blue, .mint]
    
    var data: [[Date: Double]] = []
    
    //var dateFormat : String;
    
    //var hintVisible : Bool = true;
    
    //var position : AxisMarkPosition;
    
    var dataType : DataType = .steps
    
    var body: some View {
        
        VStack(alignment: .center){
           
            Chart(data, id: \.keys.first) { intake in
               // intake.keys.first?.toString(dateFormat: DateFormat.dayWise) ?? ""
               // intake.values.first ?? 0
                BarMark(x: .value("Day", intake.keys.first?.toString(dateFormat: DateFormat.dayWise) ?? ""),
                        y: .value("Steps",intake.values.first ?? 0))
//                                .foregroundStyle(by: .value("Day", intake.keys.first?.toString(dateFormat: DateFormat.dayWise) ?? ""))
                .foregroundStyle(Color.theme.steps)
                .foregroundStyle(Color("ProgressBarColor"))
                .annotation(position: .top) {
        
                    VStack(spacing: 0) {
                    //  Text("\(Int(intake.values.first ?? 0).formatted() )")
                        
                        if(dataType == .steps){
                     //   Text("\(String(format: "%.2f", intake.values.first ?? 0))")
                            
                            Text("\(Int(intake.values.first ?? 0).formatted() )")
                          //  Text("50")
                           // Text("\(Int(intake.values.first ?? 0).formatted() )")
                            Image(systemName: "figure.step.training")
                        }else if(dataType == .distance){
                            //Text("100")
                            Text("\(String(format: "%.1f", (intake.values.first != nil ? intake.values.first!/1000 : 0) )) \n km")
                            Image(systemName: "figure.walk")
                        }
                        else if(dataType == .energy){
                           // Text("\(String(format: "%.2f", intake.values.first ?? 0)) \n kcal")
                            Text("\(Int(intake.values.first ?? 0).formatted() )\nkcal")
                            Image(systemName: "flame")
                        }
                       
                    }.font(.caption)
                    
                    //.clipped(antialiased: true)
                    //.foregroundColor(Color.theme.steps)
                    // .foregroundStyle(markColors[stepList.firstIndex(of: intake) ?? -1])
                    
                }
            }
//            .chartXAxis{
//                //AxisMarks(position: position)
//                AxisMarks(position: position, values: .stride(by:.day)){value in AxisValueLabel(format: .dateTime.weekday(), centered: true)}
//            }.chartYAxis{
//                AxisMarks(position: position, values: .stride(by:.day)){value in AxisValueLabel(format: .dateTime.weekday(), centered: true)}
//            }
            .frame(height: 400)
            
        }.padding(.top, CGFloat.theme.largeSpacing)
       
    }
  
}


//
//  HealthKitSetupAssistant.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation
import HealthKit

class HealthKitSetupAssistant {
    
    
    
    
    private enum HealthkitSetupError: Error {
        case notAvailableOnDevice
        case dataTypeNotAvailable
    }
    
    func requestPermission () async -> Bool {
        
        let stepCount = HKObjectType.quantityType(forIdentifier: .stepCount);
        //let activeEnergy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)
        let heartRate = HKObjectType.quantityType(forIdentifier: .heartRate);
//        let write: Set<HKSampleType> = [HKObjectType.workoutType(), stepCount, heartRate]
//        let read: Set = [
//            .workoutType(),
//            HKSeriesType.activitySummaryType(),
//            HKSeriesType.workoutRoute(),
//            HKSeriesType.workoutType()
//        ]
        let healthKitTypesToWrite: Set<HKSampleType> = [
            stepCount!,
            heartRate!,
            HKObjectType.workoutType()
        ]
        
        let healthKitTypesToRead: Set<HKObjectType> = [
            stepCount!,
            heartRate!,
            HKObjectType.workoutType()]

        let res: ()? = try? await HKHealthStore().requestAuthorization(toShare: healthKitTypesToWrite, read: healthKitTypesToRead)
        guard res != nil else {
            return false
        }

        return true
    }
    
    
    
    class func authorizeHealthKit(completion: @escaping (Bool, Error?) -> Swift.Void) {
        
        //1. Check to see if HealthKit Is Available on this device
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false, HealthkitSetupError.notAvailableOnDevice)
            return
        }
        
        //   2. Prepare the data types that will interact with HealthKit
        guard
            
            //let dateOfBirth = HKObjectType.characteristicType(forIdentifier: .dateOfBirth),
            //   let bloodType = HKObjectType.characteristicType(forIdentifier: .bloodType),
            // let biologicalSex = HKObjectType.characteristicType(forIdentifier: .biologicalSex),
            // let bodyMassIndex = HKObjectType.quantityType(forIdentifier: .bodyMassIndex),
            // let height = HKObjectType.quantityType(forIdentifier: .height),
            // let bodyMass = HKObjectType.quantityType(forIdentifier: .bodyMass),
            let stepCount = HKObjectType.quantityType(forIdentifier: .stepCount),
            let activeEnergy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned),
            let heartRate = HKObjectType.quantityType(forIdentifier: .heartRate),
            let distanceWalkingRunning = HKObjectType.quantityType(forIdentifier: .distanceWalkingRunning)

        else {
            
            completion(false, HealthkitSetupError.dataTypeNotAvailable)
            return
        }
        
        
        
        
        //3. Prepare a list of types you want HealthKit to read and write
        //    let healthKitTypesToWrite: Set<HKSampleType> = [bodyMassIndex,
        //                                                    activeEnergy,
        //                                                    HKObjectType.workoutType()]
        
        let healthKitTypesToWrite: Set<HKSampleType> = [
            stepCount,
            activeEnergy,
            heartRate,
            distanceWalkingRunning,
          
            HKObjectType.workoutType()
        ]
        
        let healthKitTypesToRead: Set<HKObjectType> = [
            stepCount,
            activeEnergy,
            heartRate,
            distanceWalkingRunning,
          
            HKObjectType.workoutType()]
        
        //4. Request Authorization
        HKHealthStore().requestAuthorization(toShare: healthKitTypesToWrite,
                                             read: healthKitTypesToRead) { (success, error) in
            completion(success, error)
        }
    }
    
    class func checkPermissionListEnableOrNot(completion: @escaping (Bool) -> Swift.Void)  {
        
        if (HKHealthStore().authorizationStatus(for: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!) != .sharingAuthorized) {
            completion(false )
        }else  if (HKHealthStore().authorizationStatus(for: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!) != .sharingAuthorized) {
            completion(false )
        }else  if (HKHealthStore().authorizationStatus(for: HKObjectType.workoutType()) != .sharingAuthorized) {
            completion(false )
        }else  if (HKHealthStore().authorizationStatus(for: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!) != .sharingAuthorized) {
            completion(false )
        }else  if (HKHealthStore().authorizationStatus(for: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)!) != .sharingAuthorized) {
            completion(false )
        }else {
            completion(true )
        }
    }
}

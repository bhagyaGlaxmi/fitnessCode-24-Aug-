//
//  HealthKitManager.swift
//  fitness-app
//
//  Created by Babu Lal on 19/12/22.
//

import Foundation
import HealthKit

enum HealthkitSetupError: Error {
    case notAvailableOnDevice
    case dataTypeNotAvailable
    case authorizationFailed
}

typealias CompletionHandler = (([[Date: Double]]?, Error?) -> Void)


protocol HealthStoreProtocol {
    func requestAuthorization(completion: @escaping (Bool,Error?) -> Void)
    func getSteps(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler)
    func getDistance(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler)
    func getEnergy(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler)
}


final class HealthKitManager {
    
    // MARK: - Fileprivate variables
    
    fileprivate let healthStore: HKHealthStore
    
    // MARK: - Init method
    
    init(healthStore: HKHealthStore = HKHealthStore()){
        self.healthStore = healthStore
    }
    
    
    // MARK: - Fileprivate methods
    
    fileprivate func record(data: inout [[Date: Double]], date: Date, quantity: HKQuantity) {
        // THE DATA IS BEING STORED IN A DICTIONARY
        // WHERE KEY -> DATE & VALUE -> STEPS/DISTANCE IN (COUNT/KM)
        
        var recordDict: [Date: Double] = [:]
        
        if quantity.is(compatibleWith: HKUnit.meter()) {
            let distance = quantity.doubleValue(for: HKUnit.meter())
            //recordDict[date.stringValue] = distance
            recordDict[date] = distance
        }
        
        else if quantity.is(compatibleWith: HKUnit.count()) {
            let count = quantity.doubleValue(for: HKUnit.count())
            //recordDict[date.stringValue] = count
            recordDict[date] = count
        }
        else if quantity.is(compatibleWith: HKUnit.kilocalorie()) {
            let count = quantity.doubleValue(for: HKUnit.kilocalorie())
            //recordDict[date.stringValue] = count
            recordDict[date] = count
        }
        
        data.append(recordDict)
    }
    
    fileprivate func performCollectionQuery(sampleType: HKQuantityType, startDate: Date, endDate: Date, completion: @escaping CompletionHandler) {
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate)
        var interval = DateComponents()
        interval.day = 1
        
        //print("startDate \(startDate)")
        //print("endDate\(endDate)")
        
        
        let query = HKStatisticsCollectionQuery(quantityType: sampleType,
                                                quantitySamplePredicate: predicate,
                                                options: [.cumulativeSum],
                                                anchorDate: startDate,
                                                intervalComponents: interval)
        
        query.initialResultsHandler = { query, results, error in
            if error != nil {
                completion(nil, error)
                return
            }
            
            if let myResults = results {
                
                var data: [[Date : Double]] = []
                
                myResults.enumerateStatistics(from: startDate, to: endDate) { [weak self] statistics, stop in
                    
                    if let quantity = statistics.sumQuantity() {
                        
                        self?.record(data: &data, date: statistics.endDate, quantity: quantity)
                        //print("quantity \(data)")
                    }
                    else {
                        //print("quantity_4 \(statistics.quantityType.identifier)")
                        if statistics.quantityType.identifier == HKQuantityTypeIdentifier.stepCount.rawValue {
                            let quantity = HKQuantity(unit: HKUnit.count(), doubleValue: 0.0)
                            self?.record(data: &data, date: statistics.endDate, quantity: quantity)
                           // print("quantity_1 \(quantity)")
                        }
                        else if statistics.quantityType.identifier == HKQuantityTypeIdentifier.distanceWalkingRunning.rawValue {
                            let quantity = HKQuantity(unit: HKUnit.meter(), doubleValue: 0.0)
                            self?.record(data: &data, date: statistics.endDate, quantity: quantity)
                            //print("quantity_2 \(quantity)")
                        }
                        else if statistics.quantityType.identifier == HKQuantityTypeIdentifier.activeEnergyBurned.rawValue {
                            let quantity = HKQuantity(unit: HKUnit.kilocalorie(), doubleValue: 0.0)
                            self?.record(data: &data, date: statistics.endDate, quantity: quantity)
                            //print("quantity_3 \(quantity)")
                        }
                    }
                }
                completion(data, nil)
                return
            }
            
            completion(nil, HealthkitSetupError.notAvailableOnDevice)
        }
        
        self.healthStore.execute(query)
    }
    
    fileprivate func fetchData(For sampleType: HKQuantityType, from startDate: Date, to endDate: Date, completion: @escaping CompletionHandler) {
        performCollectionQuery(sampleType: sampleType,
                               startDate: startDate,
                               endDate: endDate,
                               completion: completion)
    }
    
    
    
    
}

// MARK: - HealthStoreProtocol methods implementation
// MARK: -

extension HealthKitManager: HealthStoreProtocol {
    
    func requestAuthorization(completion: @escaping (Bool, Error?) -> Void) {
        
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false, HealthkitSetupError.notAvailableOnDevice)
            return
        }
        
        guard let distanceWalkingRunningType = HKQuantityType.quantityType(forIdentifier:.distanceWalkingRunning),
              let stepsType = HKQuantityType.quantityType(forIdentifier: .stepCount) else {
            return completion(false, HealthkitSetupError.dataTypeNotAvailable)
        }
        
        let dataTypesToRead: Set<HKObjectType> = [distanceWalkingRunningType, stepsType]
        
        healthStore.requestAuthorization(toShare: nil, read: dataTypesToRead, completion: completion)
        
    }
    
    func getSteps(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler) {
        guard let sampleTypeSteps = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount) else {
            completion(nil, HealthkitSetupError.dataTypeNotAvailable)
            return
        }
        fetchData(For: sampleTypeSteps, from: startDate, to: endDate, completion: completion)
    }
    
    func getDistance(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler) {
        guard let sampleTypeDistance = HKQuantityType.quantityType(forIdentifier:
                                                                    HKQuantityTypeIdentifier.distanceWalkingRunning) else {
            completion(nil, HealthkitSetupError.dataTypeNotAvailable)
            return
        }
        fetchData(For: sampleTypeDistance, from: startDate, to: endDate, completion: completion)
    }
    
    func getEnergy(From startDate: Date, To endDate: Date, completion: @escaping CompletionHandler) {
        guard let sampleTypeActiveEnergyBurned = HKSampleType.quantityType(forIdentifier:
                .activeEnergyBurned) else {
            completion(nil, HealthkitSetupError.dataTypeNotAvailable)
            return
        }
        //print("sampleTypeActiveEnergyBurned \(sampleTypeActiveEnergyBurned)")
        fetchData(For: sampleTypeActiveEnergyBurned, from: startDate, to: endDate, completion: completion)
       
    }
    
}

//
//  GetHealthData.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
import HealthKit

enum DataType {
    case distance
    case steps
    case energy
    case heartpoints
}
class GetHealthData {
    
    
    fileprivate lazy var healthKitManager: HealthKitManager = {
        let manager = HealthKitManager()
        return manager
    }()
    
    func fetchDataFor(numberOfDays: Int, dataType: DataType, completion: @escaping CompletionHandler) {
        // TO FETCH TODAYS DATA, KEEP numberOfDays = 1
        
        let endDate = Date()
        guard let startDate = endDate.getDateFromNow(whenDifferenceInDays: numberOfDays) else {
            return
        }
        
      
        
        switch dataType {
        case .distance:
            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .steps:
            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .energy:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .heartpoints:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        }
    }
    
    func fetchDataForCustomDate(dataType: DataType,startDateValue:Date?, endDateValue:Date?, completion: @escaping CompletionHandler) {
        // TO FETCH TODAYS DATA, KEEP numberOfDays = 1
        
        var endDate = Date()
        guard var startDate = endDate.getDateFromNow(whenDifferenceInDays: 1) else {
            return
        }
        
        if(startDateValue != nil){
          
            
            startDate = startDateValue!
            endDate = endDateValue!.endOfDay(startOfDay: endDateValue!)
            
            print ("startDateValue \(String(describing: startDate))")
            print ("endDateValue \(String(describing: endDate))")
        }
        
//        let endDate = Date()
//        let startDate = Date()
        
        switch dataType {
        case .distance:
            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .steps:
            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .energy:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        case .heartpoints:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                completion(response, error)
            }
        }
    }
}

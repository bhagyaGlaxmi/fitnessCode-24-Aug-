//
//  PieChartView.swift
//  fitness-app
//
//  Created by Babu Lal on 22/12/22.
//

import Foundation
import SwiftUI

struct PieChartView: View {
    public let values: [Double]

    public var colors: [Color]
    public let names: [String]
    
    public var backgroundColor: Color


    public var innerRadiusFraction: CGFloat
    public var hint : String
    public let heartRate: Double

    
    var slices: [PieSliceData] {
        let sum = values.reduce(0, +)
        var endDeg: Double = 0
        var tempSlices: [PieSliceData] = []
        
        for (i, value) in values.enumerated() {
            let degrees: Double = value * 360 / sum
            tempSlices.append(PieSliceData(startAngle: Angle(degrees: endDeg), endAngle: Angle(degrees: endDeg + degrees), text: String(format: "%.0f%%", value * 100 / sum), color: self.colors[i], value : value))
            endDeg += degrees
        }
        return tempSlices
    }
   // var widthValue : CGFloat  = UIScreen.main.bounds.width - 100
    var widthValue : CGFloat  = 150
    var body: some View {
        VStack{
            ZStack{
                ForEach(0..<self.values.count){ i in
                    PieSliceView(pieSliceData: self.slices[i])
                    //Text("\(i)")
                }
                .frame(width: widthValue, height: widthValue)
                
                Circle()
                    .fill(self.backgroundColor)
                    .frame(width: widthValue * innerRadiusFraction, height: widthValue * innerRadiusFraction)
                
                VStack {
//                    Text(hint)
//                        .font(.body)
//                        //.foregroundColor(Color.gray)
                    Text(String(Int(values[0])))
                        .font(.body).foregroundColor(Color.theme.steps)
                    
                    Text(String(Int(heartRate)))
                        .font(.body).foregroundColor(Color.theme.heartRate)
                }
            }
//            PieChartRows(colors: self.colors, names: self.names, values: self.values.map { String($0) }, percents: self.values.map { String(format: "%.0f%%", $0 * 100 / self.values.reduce(0, +)) })
        }
        .background(self.backgroundColor)
        //.foregroundColor(Color.white)
    
    /*    GeometryReader { geometry in
            VStack{
                ZStack{
                    ForEach(0..<self.values.count){ i in
                        PieSliceView(pieSliceData: self.slices[i])
                    }
                    .frame(width: geometry.size.width, height: geometry.size.width)
                    
                    Circle()
                        .fill(self.backgroundColor)
                        .frame(width: geometry.size.width * innerRadiusFraction, height: geometry.size.width * innerRadiusFraction)
                    
                    VStack {
                        Text("Total")
                            .font(.title)
                            .foregroundColor(Color.gray)
                        Text(String(values.reduce(0, +)))
                            .font(.title)
                    }
                }
                PieChartRows(colors: self.colors, names: self.names, values: self.values.map { String($0) }, percents: self.values.map { String(format: "%.0f%%", $0 * 100 / self.values.reduce(0, +)) })
            }
            .background(self.backgroundColor)
            .foregroundColor(Color.white)
        } */
    }
}

struct PieChartRows: View {
    var colors: [Color]
    var names: [String]
    var values: [String]
    var percents: [String]
    
    var body: some View {
        VStack{
            ForEach(0..<self.values.count){ i in
                HStack {
                    RoundedRectangle(cornerRadius: 5.0)
                        .fill(self.colors[i])
                        .frame(width: 20, height: 20)
                    Text(self.names[i])
                    Spacer()
                    VStack(alignment: .trailing) {
                      
                        Text(self.values[i])
                        Text(self.percents[i])
                            .foregroundColor(Color.gray)
                    }
                }
            }
        }
    }
}

